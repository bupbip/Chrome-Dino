let canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');

const spawnTimerLimit = 40;
const bushSize = 100;

let score;
let scoreText;
let highScore;
let highScoreText;
let gravity;
let gameSpeed;
let bushes = [];

let spacebarDown;

document.addEventListener('keydown', function (e) {
    if (e.code == "Space") {
        spacebarDown = true; // записываем нажатие в массив
    }
});

document.addEventListener('keyup', function (e) {
    if (e.code == "Space") {
        spacebarDown = false; // отпустил кнопку
    }
})


class Player {
    constructor(x, y, w, h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;

        this.dy = 0; // сила прыжка
        this.jumpForce = 15; // дальность прыжка
        this.standartHeight = h;
        this.grounded = false;
        this.jumpTimer = 0;
        this.prevY = y; // считывать последнюю высоту
    }

    Animate() {
        // Прыжок
        if (spacebarDown) {
            this.Jump();
        } else {
            this.jumpTimer = 0;
        }
        this.prevY = this.y;
        this.y += this.dy;
        // Гравитация
        if (this.y + this.h < canvas.height) {
            this.dy += gravity;
            this.grounded = false;
        } else {
            this.dy = 0; // на земле
            this.grounded = true;
            this.y = canvas.height - this.h;
        }

        this.Draw();
    }

    Jump() {
        if (this.grounded && this.jumpTimer == 0) { // точечный прыжок
            this.jumpTimer = 1;
            this.dy = - this.jumpForce;
        } else if (this.jumpTimer > 0 && this.jumpTimer < 15) { // 15 - макс значение
            this.jumpTimer++;
            this.dy = - this.jumpForce - this.jumpTimer / 4;
        }
    }

    Draw() {
        ctx.beginPath();
        const img = document.createElement("img");
        if (this.prevY > this.y) {
            img.src = 'images/startJumpV1.png';
        } else if (this.prevY < this.y) {
            img.src = 'images/endJumpV1.png';
        } else {
            img.src = 'images/rabbit.png';
        }
        ctx.drawImage(img, this.x, this.y, this.h, this.h);
        console.log(gameSpeed);
        ctx.closePath();
    }
}

class Bush {
    constructor(x, y, w, h, name) {
        this.name = name;
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
  
        this.dx = -gameSpeed;
    }
  
    Update () {
        this.x += this.dx;
        this.Draw();
        this.dx = -gameSpeed;
    }
  
    Draw () {
        ctx.beginPath();
        let img = document.createElement("img");
        img.src = this.name;
        ctx.drawImage(img, this.x, this.y, Math.round(this.w), Math.round(this.h));
        ctx.closePath();
    }
  }

class Text {
    constructor(text, x, y, allign, color, size) { // a - allign(выравнивание)
        this.text = text;
        this.x = x;
        this.y = y;
        this.allign = allign;
        this.color = color;
        this.size = size;
    }

    Draw() {
        ctx.beginPath();
        ctx.fillStyle = this.color;
        ctx.font = this.size + "px sans-serif";
        ctx.textAlign = this.allign;
        ctx.fillText(this.text, this.x, this.y);
        ctx.closePath();
    }
}


function SpawnBushes() {
    picName = 'images/trees/tree' + (Math.ceil(Math.random()*3) - 1) + '.png'; // случайное дерево
    let img = document.createElement("img");
    img.src = picName;
    img.onload = function() {
        let imgW = this.width / 2;
        let imgH = this.height / 2;
        let bush = new Bush(canvas.width + imgW, canvas.height - imgH, imgW, imgH, picName);
        bushes.push(bush)
    }
}


function Start () { // Запуск всея руси
    canvas.width = window.innerWidth; // размеры сцены как размеры экрана
    canvas.height = window.innerHeight - 100;

    //ctx.font = "20px sans-serif"; todo нахуя

    gameSpeed = 5; // обычная скорость игры
    gravity = 1; // гравитация 

    score = 0; // обнуление
    highScore = 0;


    scoreText = new Text("Очки: " + score, 25, 25, "left", "#212121", "20");
    highScoreText = new Text("Рекорд: " + highScore, canvas.width - 25, 25, "right", "#212121", "20");
    player = new Player(25,0,60,60,'#FBCEB1');
    player.Draw();

    requestAnimationFrame(Update); // говорим что нужно обновить объекты след 
                                   //кадром через функцию update
}


const initialSpawnTimer = 200;
let spawnTimer = initialSpawnTimer;
function Update() {
    requestAnimationFrame(Update) // держим функцию в цикле
    ctx.clearRect(0, 0, canvas.width, canvas.height); // очистка экрана

    spawnTimer--; // каждый кадр уменьшаем таймер
    if (spawnTimer <= 0) {
        imgName = SpawnBushes();
        spawnTimer = initialSpawnTimer - gameSpeed * 8; // ускорение игры
        if (spawnTimer < spawnTimerLimit) { // для того чтобы не было слишком быстро
            spawnTimer = spawnTimerLimit;
        }
    }

    score++;
    scoreText.text = "Очки: " + score;
    scoreText.Draw();
    highScore = Math.max(score, highScore);
    highScoreText.text = "Рекорд: " + highScore;
    highScoreText.Draw();


    player.Animate();

    for (let i = 0; i < bushes.length; i++) {
        let b = bushes[i];

        if (b.x + b.width < 0) { // убираем с массива если вышел за пределы
            bushes.splice(i, 1);
        }

        if (
            player.x < b.x + b.w &&
            player.x + player.w > b.x &&
            player.y < b.y + b.h &&
            player.y + player.h > b.y            
        ) {
            bushes = [];
            score = 0;
            spawnTimer = initialSpawnTimer;
            gameSpeed = 5;
        }

        b.Update(imgName);
    }
    gameSpeed += 0.003; // ускорим игру
}

Start();